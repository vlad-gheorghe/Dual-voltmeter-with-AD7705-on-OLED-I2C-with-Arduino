AD770X
======

Arduino Library for AD7705/AD7706

This is an Arduino Library for AD7705/AD7706 A/D converter. More details can be found here:

<a href="http://www.kerrywong.com/2012/04/18/ad7705ad7706-library-revisited/">AD7705/AD7706 Library Revisited</a><br />
<a href="http://www.kerrywong.com/2011/03/20/ad7705ad7706-library/">AD7705/AD7706 Library</a>

